

<?php
/**
 * These are the database login details
 */  
define("HOST", "localhost");     // The host you wa
define("USER", "sec_user");    // The database username. 
define("PASSWORD", "Uzg82t=u%#bNgPJw");    // The database password. 
define("DATABASE", "GPA_Tracker");    // The database name.
 
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");
 
define("SECURE", FALSE);    // FOR DEVELOPMENT ONLY!!!!
?>
