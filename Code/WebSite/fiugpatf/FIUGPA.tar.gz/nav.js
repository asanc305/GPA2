var xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function() {
	if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
		document.getElementById("nav").innerHTML = xmlhttp.responseText;
	}
}

xmlhttp.open("GET", "nav.php", true);
xmlhttp.send();

