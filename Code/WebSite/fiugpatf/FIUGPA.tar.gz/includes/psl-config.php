<?php
/**
 * These are the database login details
 */
define("HOST","localhost");
define("USER","sec_user");
define("PASSWORD", "Uzg82t=u%#bNgPJw");
define("DATABASE", "GPA_Tracker");

define("CAN_REGISTER","any");
define("DEFAULT_ROLE", "member");

define("SECURE", FALSE);
?>